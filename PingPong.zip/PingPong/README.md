# toyCarBluetoothApp

## For more detail, please refer : https://youtu.be/25YA3VVPu80

![](https://github.com/rohitCodeRed/toyCarBluetoothApp/blob/gif_upload/android_app_1.gif)
