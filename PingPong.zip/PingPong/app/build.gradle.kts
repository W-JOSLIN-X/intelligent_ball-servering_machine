plugins {
    id("com.android.application")//声明这是一个Android app项目不是一个库
    id("org.jetbrains.kotlin.android")//使用kotlin来编写
}

android {
    namespace = "com.example.PingPongapp"
    compileSdk = 34
    //配置项目的默认属性
    defaultConfig {
        applicationId = "com.example.PingPongapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1//内部版本号，用于在play商店升级
        versionName = "1.0"//展示给用户的版本

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" //指定 Android 单元测试使用的测试运行器。
    }
    //构建类型配置
    buildTypes {
        release {
            isMinifyEnabled = false //发布版本不开启代码混淆/压缩（调试方便）,下面的两个文件就是相关的代码内容
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    //核心依赖
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    //生命周期与导航
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("androidx.navigation:navigation-fragment-ktx:2.6.0")
    implementation("androidx.navigation:navigation-ui-ktx:2.6.0")
    //测试依赖
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}